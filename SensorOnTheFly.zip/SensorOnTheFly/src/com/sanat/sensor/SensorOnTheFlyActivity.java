package com.sanat.sensor;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings("deprecation")
public class SensorOnTheFlyActivity extends Activity implements SensorEventListener {
    
	Button sensorButton;
	TextView sensorValueTextView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //SensorManager mySensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        sensorValueTextView = (TextView)findViewById(R.id.sensorValueTextView);
        sensorButton = (Button)findViewById(R.id.sensorButton);
        sensorButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				SensorManager mySensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
				boolean registerResult = mySensorManager.registerListener
						(SensorOnTheFlyActivity.this, 
						mySensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
						SensorManager.SENSOR_DELAY_NORMAL);
				if(registerResult){
					//Write the logic here
				}else{
					Toast.makeText(SensorOnTheFlyActivity.this, "Sensor not found", Toast.LENGTH_LONG).show();
				}
				
			}
		});
    }

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		String sensorOutput = "";
		for(float f : event.values){
			sensorOutput += String.valueOf(f) + ":";
		}
		sensorOutput = sensorOutput.substring(0, sensorOutput.length()-1);
		sensorValueTextView.setText(sensorOutput);
		
	}
}