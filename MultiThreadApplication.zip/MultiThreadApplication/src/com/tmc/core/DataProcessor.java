package com.tmc.core;

public class DataProcessor {

	public String readData(String siteName){
		System.out.println("Reading data from " + siteName);
		String data = null;
		try {
			Thread.sleep(4 * 1000);
			data = "Data from " + siteName;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	
	public String transformData(String data){
		System.out.println("Transforming data...");
		String processedData = null;
		try {
			Thread.sleep(3 * 1000);
			processedData = "PROCESSED DATA";
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return processedData;
	}
	
	public String concatData(String data1, String data2){
		System.out.println("Concatenating Data...");
		try {
			Thread.sleep(2 * 1000);
			return data1 + data2;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;		
	}
	
	public int outputData(String data){
		System.out.println("Outputting data...");
		int exitCode = 0;
		try {
			Thread.sleep(5 * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			exitCode = -1;
		}
		return exitCode;
	}
}
