package com.tmc.core;

import java.util.Date;

public class ExecutionPoint {
	static String site1Data;
	static String site2Data;
	static String transFormData1 = null;
	static String transFormData2 = null;

	public static void main(String[] args) {
		//Single Threaded Implementation
		int exitCode = singleThreadedImplementation();
		System.out.println("Single Threaded implementation finished with exit code : " + exitCode);
		exitCode = multiThreadedImplementation();
		System.out.println("Multi Threaded implementation finished with exit code : " + exitCode);
	}

	public static int singleThreadedImplementation(){
		DataProcessor dataProcessor = new DataProcessor();
		System.out.println("Single Threaded Start Time : " + new Date().toString());
		String site1Data = dataProcessor.readData("Site1");
		String site2Data = dataProcessor.readData("Site2");
		String transFormedData1 = dataProcessor.transformData(site1Data);
		String transFormedData2 = dataProcessor.transformData(site2Data);
		String finalData = dataProcessor.concatData(transFormedData1, transFormedData2);
		int output = dataProcessor.outputData(finalData);
		System.out.println("Single Threaded End Time : " + new Date().toString());
		return output;
	}
	
	public static int multiThreadedImplementation(){
		final DataProcessor dataProcessor = new DataProcessor();
		Runnable readRunnable1 = new Runnable() {

			@Override
			public void run() {
				dataProcessor.readData("Site1");
				System.out.println("Finished readRunnable1...");

			}
		};
		final Thread readThread1 = new Thread(readRunnable1);
		System.out.println("Multi Threaded Start Time : " + new Date().toString());
		readThread1.start();

		Runnable readRunnable2 = new Runnable(){
			@Override
			public void run() {
				site1Data = dataProcessor.readData("Site2");
				System.out.println("Finished readRunnable2...");
			}

		};
		final Thread readThread2 = new Thread(readRunnable2);
		readThread2.start();

		Runnable transformRunnable1 = new Runnable() {

			@Override
			public void run() {
				try {
					readThread1.join();
					System.out.println("Starting transformRunnable1...");
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				transFormData1 = dataProcessor.transformData(site1Data);
			}
		};

		Thread transformThread1 = new Thread(transformRunnable1);
		transformThread1.start();
		
		Runnable transformRunnable2 = new Runnable() {

			@Override
			public void run() {
				try {
					readThread2.join();
					System.out.println("Starting transformRunnable2...");
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				transFormData2 = dataProcessor.transformData(site2Data);
			}
		};
		
		Thread transformThread2 = new Thread(transformRunnable2);
		transformThread2.start();
		while(transformThread1.isAlive() || transformThread2.isAlive()){
			continue;
		}
		String outputData = dataProcessor.concatData(transFormData1, transFormData2);
		int exitCode = dataProcessor.outputData(outputData);
		System.out.println("Multi Threaded End Time : " + new Date().toString());
		return exitCode;
	}

}
