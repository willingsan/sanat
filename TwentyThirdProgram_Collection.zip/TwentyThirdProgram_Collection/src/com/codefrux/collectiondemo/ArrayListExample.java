package com.codefrux.collectiondemo;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.ArrayList;

public class ArrayListExample {
	/*
	 * 1. ArrayLists are Sequence Type
	 * 2. ArrayLists are not synchronous that is they are not thread-safe
	 * 3. Capacity of ArrayList can't be obtained
	 * 4. Only Initial size can be specified
	 */
	public static void main(String[] args) {
		
		String[] countries = {"INDIA", "US", "BRITAIN"};
		//Generic based ArrayList
		ArrayList<String> myArrayList = new ArrayList<String>(); //Default capacity is 10
		
		//Non-generic type. Not recommended
		ArrayList nonGenericArrayList = new ArrayList();
				
		for(String country : countries){
			myArrayList.add(country);
		}
		
		//Iterating through the ArrayList using Iterator
		ListIterator<String> ArrayListIterator = myArrayList.listIterator();
		while(ArrayListIterator.hasNext()){
			System.out.println(ArrayListIterator.next());
		}
		
		System.out.println("------------------------------------------");
		
		//Adding a new element
		myArrayList.add("GERMANY");
		
		//Updating an existing element
		myArrayList.set(1, "USA");
		
		//Adding an element at a particular position
		myArrayList.add(4, "CHINA");
		
		//Iterating through the ArrayList using for...each loop
		for(String name : myArrayList){
			System.out.println(name);
		}
		
		System.out.println("------------------------------------------");
		
		//Initializing both Capacity and size
		
		ArrayList<String> initSizeAndCapacity = new ArrayList<String>(3);
		initSizeAndCapacity.addAll(myArrayList);
		for(int i = 0; i < initSizeAndCapacity.size(); i++){
			System.out.println(initSizeAndCapacity.get(i));
		}
		
		System.out.println("------------------------------------------");
		
		//Converting to Array
		String[] dataAsArray = initSizeAndCapacity.toArray(
				new String[initSizeAndCapacity.size()]);
		for(String data: dataAsArray){
			System.out.println(data);
		}
		
		System.out.println("------------------------------------------");
	}

}
