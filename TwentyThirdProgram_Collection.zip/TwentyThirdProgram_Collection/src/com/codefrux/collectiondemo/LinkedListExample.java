package com.codefrux.collectiondemo;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] countries = {"INDIA", "US", "BRITAIN"};
		//Generic based ArrayList
		LinkedList<String> myLinkedList = new LinkedList<String>(); //Default capacity is 10

		//Non-generic type. Not recommended
		LinkedList nonGenericArrayList = new LinkedList();

		for(String country : countries){
			myLinkedList.add(country);
		}

		//Iterating through the ArrayList using Iterator
		ListIterator<String> listIterator = myLinkedList.listIterator();
		while(listIterator.hasNext()){
			System.out.println(listIterator.next());
		}

		System.out.println("------------------------------------------");

		//Adding a new element
		myLinkedList.add("GERMANY");

		//Updating an existing element
		myLinkedList.set(1, "USA");

		//Adding an element at a particular position
		myLinkedList.add(4, "CHINA");

		//Iterating through the ArrayList using for...each loop
		for(String name : myLinkedList){
			System.out.println(name);
		}

		System.out.println("------------------------------------------");

		myLinkedList.addFirst("AUSTRALIA");
		myLinkedList.addLast("ZIMBABWE");

		//Iterating through the ArrayList using for...each loop
		for(String name : myLinkedList){
			System.out.println(name);
		}

		System.out.println("------------------------------------------");
		
		
		

	}

}
