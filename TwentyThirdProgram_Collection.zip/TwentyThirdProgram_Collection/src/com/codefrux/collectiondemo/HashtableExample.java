package com.codefrux.collectiondemo;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashtableExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Hashtable<Integer, String> myTable = new Hashtable<Integer, String>();
		myTable.put(1, "USA");
		myTable.put(2, "INDIA");
		myTable.put(3, "CHINA");
		
		//Accessing Values....
		for(String val: myTable.values()){
			System.out.println(val);
		}
		
		//Accessing Values....
		Set<Integer> myTableKeys = myTable.keySet();
		for(Integer i: myTableKeys){
			System.out.println(myTable.get(i));
		}
		
		//Accessing Values...
		
		Iterator<String> mapIter = myTable.values().iterator();
		while(mapIter.hasNext()){
			System.out.println(mapIter.next());
		}

	}

}
