package com.codefrux.collectiondemo;

import java.util.ListIterator;
import java.util.Vector;

/*
 * 1. Vectors are Sequence Type
 * 2. Vectors are synchronous that is they are thread-safe
 * 3. Capacity of vector can be obtained
 * 4. Capacity and initial size both can be specified
 */

public class VectorExample {

	public static void main(String[] args) {
		
		String[] countries = {"INDIA", "US", "BRITAIN"};
		//Generic based Vector
		Vector<String> myVector = new Vector<String>();	//Default capacity is 10
		System.out.println(myVector.capacity());
		
		//Non-generic type. Not recommended
		Vector nonGenericVector = new Vector();
				
		for(String country : countries){
			myVector.add(country);
		}
		
		//Iterating through the vector using Iterator
		ListIterator<String> vectorIterator = myVector.listIterator();
		while(vectorIterator.hasNext()){
			System.out.println(vectorIterator.next());
		}
		
		//Adding a new element
		myVector.add("GERMANY");
		
		//Updating an existing element
		myVector.set(1, "USA");
		
		//Adding an element at a particular position
		myVector.add(4, "CHINA");
		
		//Iterating through the vector using for...each loop
		for(String name : myVector){
			System.out.println(name);
		}
		
		//Initializing both Capacity and size
		
		Vector<String> initSizeAndCapacity = new Vector<String>(100, 10);
		initSizeAndCapacity.addAll(myVector);
		for(int i = 0; i < initSizeAndCapacity.size(); i++){
			System.out.println(initSizeAndCapacity.get(i));
		}
		
	}

}
