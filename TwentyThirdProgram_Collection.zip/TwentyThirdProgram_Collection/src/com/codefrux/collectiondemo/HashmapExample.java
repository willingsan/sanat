package com.codefrux.collectiondemo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashmapExample {

	//1.	Default capacity for Hashmap is 16.
	//2.	Load factor is 0.75
	//3.	Hashmaps are not synchronized.
		
	public static void main(String[] args) {
		
		HashMap<Integer, String> myMap = new HashMap<Integer, String>();
		myMap.put(1, "USA");
		myMap.put(2, "INDIA");
		myMap.put(3, "CHINA");
		
		//Accessing Values....
		for(String val: myMap.values()){
			System.out.println(val);
		}
		
		//Accessing Values....
		Set<Integer> myMapKeys = myMap.keySet();
		for(Integer i: myMapKeys){
			System.out.println(myMap.get(i));
		}
		
		//Accessing Values...
		
		Iterator<String> mapIter = myMap.values().iterator();
		while(mapIter.hasNext()){
			System.out.println(mapIter.next());
		}

	}

}
