package com.codefrux.collectiondemo;

import java.util.EnumSet;
import java.util.Iterator;

public class SetExample {

	enum Weekdays{MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY};
	
	
	public static void main(String[] args) {
		EnumSet<Weekdays> daySet = EnumSet.of(Weekdays.MONDAY, Weekdays.THURSDAY);
		
		Iterator<Weekdays> setIter = daySet.iterator();
		while(setIter.hasNext()){
			System.out.println(setIter.next());
		}
		
		//Creating EnumSet using Range
		
		daySet = EnumSet.range(Weekdays.MONDAY, Weekdays.THURSDAY);
		setIter = daySet.iterator();
		while(setIter.hasNext()){
			System.out.println(setIter.next());
		}
	}
	
}
