package com.tmc.somedemo;

public class FirstThread implements Runnable{

	@Override
	public void run() {
		System.out.println("My Thread Has Started....");
		for (int i = 0; i < 10; i++) {
			System.out.println("i : " + i);
			try {
				Thread.sleep(2 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
}
