package com.tmc.somedemo;

public class EntryPoint {

	
	public static void main(String[] args) {
		SecondThread st = new SecondThread();
		st.start();
	}

	
	public static void runnableThreads(){
		FirstThread firstThread = new FirstThread();
		Thread t = new Thread(firstThread);
		t.start();
	//	firstThread.run();
		System.out.println("ok!");
		
		FirstThread secondThread = new FirstThread();
		t = new Thread(secondThread);
		t.start();
		
	}
	
}
