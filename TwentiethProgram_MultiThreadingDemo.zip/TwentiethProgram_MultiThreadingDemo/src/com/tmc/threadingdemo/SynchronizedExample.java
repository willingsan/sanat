package com.tmc.threadingdemo;

public class SynchronizedExample{

	static int[] someArray = {1,2,3,4,5};
	private int sum;
	//	synchronized - put this keyword
	 synchronized void doSum(){
		sum = 0;
		for(int i=0; i < someArray.length; i++){			
			try {
				Thread.sleep(1 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sum = sum + someArray[i];
			System.out.println("sum is : " + sum);
		}
	}

	void unsynchronizedSum(){
		sum = 0;
		for(int i=0; i < someArray.length; i++){			
			try {
				Thread.sleep(1 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sum = sum + someArray[i];
			System.out.println("sum is : " + sum);
		}
	}


}
