package com.tmc.threadingdemo;

public class ThreadingDemo {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		FirstThreadWithRunnable firstThread = new FirstThreadWithRunnable();
		Thread startThread = new Thread(firstThread);
		startThread.start();
		System.out.println("going to wait...");
		startThread.join(10 * 1000);
		
		ThreadWithExtendingThread newThread = new ThreadWithExtendingThread();
		newThread.start();
		while(startThread.isAlive() || newThread.isAlive()){
			continue;
		}
		
		System.out.println("All threads are done. Now I am exiting...");
	}

}
