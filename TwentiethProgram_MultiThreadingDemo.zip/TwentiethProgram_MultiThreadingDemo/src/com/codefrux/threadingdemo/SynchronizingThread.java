package com.codefrux.threadingdemo;

public class SynchronizingThread extends Thread{

	static SynchronizedExample syncExample = new SynchronizedExample();
	static Object obj = new Object();
	/*
	@Override
	public void run() {
		// 
		syncExample.doSum();
	}
	*/
	
	@Override
	public void run() {
		synchronized (obj) {
			syncExample.unsynchronizedSum();
		}
	}
	
	

}
