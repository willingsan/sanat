package com.codefrux.threadingdemo;

public class SynchronizedDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SynchronizingThread syncThread = new SynchronizingThread();
		syncThread.start();
		
		SynchronizingThread syncThreadNew = new SynchronizingThread();
		syncThreadNew.start();
		
		
	}

}
