package com.codefrux.threadingdemo;

public class SimpleThreadingDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FirstThreadWithRunnable firstThread = new FirstThreadWithRunnable();

		Thread myFirstThread = new Thread(firstThread);
		myFirstThread.start();
		System.out.println("I am on the main thread.");
	}

}
