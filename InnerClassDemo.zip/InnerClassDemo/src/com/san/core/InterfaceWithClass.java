package com.san.core;

public interface InterfaceWithClass {
	
	public class ClassInsideInterface{
		public void printSomething(){
			System.out.println("Hey ! I am printing from within a class defined inside an interface.");
		}
	}

}
