package com.san.core;

public class StaticInnerClass {
	static int data=30;

	static class Inner{  
		void displayMsg(){
			System.out.format("Data is %d", data);
		}  
	}  

	public static void main(String args[]){  
		StaticInnerClass.Inner obj=new StaticInnerClass.Inner();
		obj.displayMsg();  
	}  
}  

