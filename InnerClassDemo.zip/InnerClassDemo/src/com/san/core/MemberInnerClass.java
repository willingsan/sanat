package com.san.core;

public class MemberInnerClass {

	int serialNumber = 100;
	
	class InnerClass{
		public void printLocation(){
			System.out.println("Called from InnerClass method printLocation. Value of serial number is : " + serialNumber);
		}
	}
	
	public static void main(String[] args) {
		//Instantiating an inner class
		MemberInnerClass.InnerClass innerClass = new MemberInnerClass().new InnerClass();
		innerClass.printLocation();
		
		MemberInnerClass mic = new MemberInnerClass();
		//Instantiating an inner class by calling the new operator on the object of outer class.	
		MemberInnerClass.InnerClass secondInnerClass = mic.new InnerClass();
		mic.serialNumber = 200;
		secondInnerClass.printLocation();
	}
	
}
