package com.san.core;

public abstract class SimpleAbstractClass {
	
	int value = 500;
	
	public abstract void printSomeValue();

	public void printLocalValue(){
		System.out.println(value);
	}
	
}
