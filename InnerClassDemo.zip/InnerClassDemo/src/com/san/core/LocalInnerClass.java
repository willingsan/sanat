package com.san.core;

public class LocalInnerClass {

	int instValue = 100;
	
	public void withLocalInnerClass(){
		
		final int value = 40;		
		class ClassWithinMethod{
			void displaySomeText(){
				System.out.println(value);
				System.out.println(instValue);
				System.out.println("Displaying data from displaySomeText method of a local inner class.");
			}
		}
		
		ClassWithinMethod cwm = new ClassWithinMethod();
		cwm.displaySomeText();
		
	}
	
	public static void main(String[] args) {
		LocalInnerClass lic = new LocalInnerClass();
		lic.withLocalInnerClass();
	}
	
}
