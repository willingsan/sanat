package com.san.core;

public class AnonymousClas {

	SimpleAbstractClass abstractClass = new SimpleAbstractClass() {

		@Override
		public void printSomeValue() {
			System.out.println("Printing value from anonymous implementation of abstract class.");

		}
	};

	public void getValueFromAbstract(){

		abstractClass.printLocalValue();
	}

	public static void main(String[] args) {
		AnonymousClas anonymousClass = new AnonymousClas();
		anonymousClass.getValueFromAbstract();
		anonymousClass.abstractClass.printSomeValue();
	}

}
