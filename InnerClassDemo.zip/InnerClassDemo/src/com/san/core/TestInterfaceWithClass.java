package com.san.core;

public class TestInterfaceWithClass implements InterfaceWithClass {

	public static void main(String[] args) {
		//Accessing interface class using Interface signature
		InterfaceWithClass.ClassInsideInterface cii = new InterfaceWithClass.ClassInsideInterface();
		cii.printSomething();
		
		//Accessing the ClassInsideInterface class made available due to inheritance.
		ClassInsideInterface ci1 = new ClassInsideInterface();
		ci1.printSomething();
		
	}
	
}
